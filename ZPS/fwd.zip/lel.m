% wavedemo
close all;
clear all;

prog = 0
% Q = -8 dla kosinusowej
Q=0.5
img = imread('noise.jpg');
figure;
imshow(img);
% r_im = uint8(img(:,:,1));
% g_im = uint8(img(:,:,2));
% b_im = uint8(img(:,:,3));
r_im = double(img(:,:,1));
g_im = double(img(:,:,2));
b_im = double(img(:,:,3));
% transformata kosinusowa
% r_trans=dct2(r_im);
% g_trans=dct2(g_im);
% b_trans=dct2(b_im);
% transformata wlasha hadamada
% r_trans=fwht(fwht(r_im)');
% g_trans=fwht(fwht(g_im)');
% b_trans=fwht(fwht(b_im)');
[x y z] = size(img);


% progowanie
% for i=1:x
%     for j=1:y
%         if abs(r_trans(i, j)) <= prog
%             r_trans(i, j) = 0;
%         end
%         if abs(g_trans(i, j)) <= prog
%             g_trans(i, j) = 0;
%         end
%         if abs(b_trans(i, j)) <= prog
%             b_trans(i, j) = 0;
%         end
%     end
% end


% kwantowanie
% for i=1:x
%     for j=1:y
%         r_trans(i, j) = floor(r_trans(i, j)*2^Q + 0.5)/2^Q;
%         g_trans(i, j) = floor(g_trans(i, j)*2^Q + 0.5)/2^Q;
%         b_trans(i, j) = floor(b_trans(i, j)*2^Q + 0.5)/2^Q;
%     end
% end
lel_r=fwht(fwht(r_im)');
lel_g=fwht(fwht(g_im)');
lel_b=fwht(fwht(b_im)');
r_ret=ifwht(ifwht(floor(lel_r*2^Q + 0.5)/2^Q)');
g_ret=ifwht(ifwht(floor(lel_g*2^Q + 0.5)/2^Q)');
b_ret=ifwht(ifwht(floor(lel_b*2^Q + 0.5)/2^Q)');

% odwrotna kosinusowa
% r_ret=idct2(r_trans);
% g_ret=idct2(g_trans);
% b_ret=idct2(b_trans);
% odwrotna wht
% r_ret=ifwht(ifwht(r_trans)');
% g_ret=ifwht(ifwht(g_trans)');
% b_ret=ifwht(ifwht(b_trans)');
%wy�wietl
out = zeros(x, y, 3);
out(:,:,1) = r_ret;
out(:,:,2) = g_ret;
out(:,:,3) = b_ret;
out = uint8(out);
out(abs(out)<prog)=0;
figure;
imshow(out);
figure;
imshow(imread('clean.jpg')-out);
% kwantowanie/progowanie
% odwrotna
%w wy�wietl
%policz b��d


